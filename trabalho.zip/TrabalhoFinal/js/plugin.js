$(document).ready(function() {
	
         // $('#featured').orbit({
         //      bullets: true
         // });
});

